console.log("Name : Aman Mujawar");
console.log("Branch : IT");
console.log("Year : TE");