const express = require('express');
const app = express();

app.use(express.static('public'));

// message when our server get started
app.listen(4000,()=>{
    console.log("Server is started");
})